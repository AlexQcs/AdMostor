package com.alex.mvp.view;

/**
 * @author alex
 * @date 2017/11/17
 * @description 所有View层接口的基类
 */
public interface BaseMvpView {
}
